package Tasks.Lab8;

public class NieprawidlowyAdresException extends RuntimeException {
    public NieprawidlowyAdresException(String message) {super(message);
    }
}
