package Tasks.Lab12;

public class TasksLab12 {
    public void Task01() {

    }
}
