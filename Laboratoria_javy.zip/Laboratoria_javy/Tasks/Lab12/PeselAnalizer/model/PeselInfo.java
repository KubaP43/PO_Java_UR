package Tasks.Lab12.PeselAnalizer.model;

public class PeselInfo {
    public static void main(String[] args) {

        //sciezka do pliku
        String fileName = "pesele.txt";

    }
}
