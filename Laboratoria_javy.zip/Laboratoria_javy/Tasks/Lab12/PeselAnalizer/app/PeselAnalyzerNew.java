package Tasks.Lab12.PeselAnalizer.app;
//klasa uruchomieniowa zawiarajaca glowne komponenty programu run
public class PeselAnalyzerNew {
}
