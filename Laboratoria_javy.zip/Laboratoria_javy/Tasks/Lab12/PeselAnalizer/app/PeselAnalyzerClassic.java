package Tasks.Lab12.PeselAnalizer.app;

public class PeselAnalyzerClassic {
}
