package Tasks.Lab12.PeselAnalizer.utility;
//klasa pomocnicza do pracy z plikami
public class FileManager {
}
