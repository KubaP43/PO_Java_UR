package Tasks.Lab12.PeselAnalizer;

public class w {
}
